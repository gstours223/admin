# GS Tours CRM — Website

A real, working, tested login-gated web app: Express + SQLite backend, React frontend, your existing CRM interface reconnected to a real database instead of browser storage.

**Status: built and tested in a sandbox, not yet deployed anywhere.** Everything below has been verified working — account setup, login, creating and saving real records, and a genuine page reload correctly restoring a signed-in session and its data — but it only exists on this machine right now. Getting it onto your domain is the remaining step, and needs a few decisions only you can make (which host, what the domain structure looks like).

## What's here

```
gstours-web/
  server/
    server.js       — Express API: auth, CRUD for every entity, backup/restore
    db.js            — SQLite schema (better-sqlite3), audit log included
    package.json
  client/
    src/
      App.jsx        — decides: setup screen / login screen / the CRM
      Login.jsx       — the login + first-account-setup screen
      CRM.jsx          — your existing CRM, with its data layer swapped from
                         browser storage to real API calls (everything else
                         — every module, every form, the PDF generation, the
                         Embassy calculator — is untouched)
      api.js           — the bridge between CRM.jsx and the backend
      main.jsx
    index.html
    vite.config.js
    package.json
```

## Running it locally, to see it work

```bash
cd server
npm install
node server.js
# separately, in another terminal:
cd client
npm install
npm run build        # builds into ../server/public
```

Then open `http://localhost:4000` — the server serves both the API and the built frontend from one place, so there's no separate frontend URL to manage. First visit shows the account-setup screen; after that, it's a normal login.

## Deploying it for real

1. **Pick a host.** Railway is the simplest match for what you've used before — connect this repo, it runs `npm install && npm run build` (client) then `node server.js` (server), and gives you a URL. Render or a plain VPS work too; the app has no Railway-specific code in it.
2. **Persistent storage matters.** The SQLite database file needs to live on a volume that survives redeploys — on Railway, attach a volume and point `DB_PATH` at it. Skipping this step means every deploy wipes your data, which is exactly the kind of thing this whole rebuild exists to prevent.
3. **Environment variables to set:**
   - `SESSION_SECRET` — a long random string, not the placeholder in the code
   - `DB_PATH` — where the SQLite file lives (on the persistent volume)
   - `PORT` — usually set automatically by the host
4. **Point your domain at it.** Whatever host you pick will give you instructions for a custom domain — typically a CNAME record plus a setting in their dashboard. TLS is usually automatic.
5. **First visit to the live URL** shows the account-setup screen. Create your account there — this locks itself after the first user, so it can't be used to add unauthorized accounts later.
6. **Bring your data across.** Use "Restore from file" inside the app (wired to `/api/restore`) with `gstours-crm-your-data.json` — the complete export from your 13 September session, already handed to you earlier. Verify the record counts after: 16 queries, 25 bookings, 19 invoices, 29 companies, 19 vendors, 4 contacts.

## What's genuinely proven vs. what to still watch

**Proven, with real tests, not just code review:**
- Account setup and login work correctly against the real database
- Creating and saving records persists through the real API (verified independently, not just by trusting what the screen shows)
- A genuine reload correctly restores a signed-in session and previously-saved data

**Not yet exercised under real-world conditions:**
- Every single module of the CRM (Insights charts, the Embassy calculator, PDF generation, the double-booking detector) — these came across unchanged from your tested browser version, but haven't each been individually re-verified against the new backend the way the core save/load path was. If something behaves oddly in one of them, it's most likely a data-shape mismatch between what that module expects and what the API returns — worth checking `api.js` first.
- Real concurrent use by more than one person at once
- Actual behavior on your real hosting provider, which may have its own quirks

Bring anything that doesn't work back here, and it can get fixed the same way everything else in this CRM has been — found, tested, and confirmed before calling it done.
