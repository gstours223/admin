const BASE = import.meta.env.VITE_API_BASE || '/api';

async function request(path, opts = {}) {
  const res = await fetch(BASE + path, {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
    ...opts
  });
  if (res.status === 401) {
    const err = new Error('Not signed in');
    err.unauthorized = true;
    throw err;
  }
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Request failed: ${res.status}`);
  }
  if (res.status === 204) return null;
  return res.json();
}

export const api = {
  list: (entity) => request(`/${entity}`),
  upsert: (entity, record) => request(`/${entity}/${record.id}`, { method: 'PUT', body: JSON.stringify(record) }),
  remove: (entity, id) => request(`/${entity}/${id}`, { method: 'DELETE' }),

  getSettings: () => request('/settings'),
  putSettings: (settings) => request('/settings', { method: 'PUT', body: JSON.stringify(settings) }),

  getMeta: () => request('/meta'),
  putMeta: (meta) => request('/meta', { method: 'PUT', body: JSON.stringify(meta) }),

  backup: () => request('/backup'),
  restore: (data) => request('/restore', { method: 'POST', body: JSON.stringify(data) }),

  authStatus: () => request('/auth/status'),
  login: (email, password) => request('/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) }),
  logout: () => request('/auth/logout', { method: 'POST' }),
  me: () => request('/auth/me'),
  setup: (email, password, name) => request('/auth/setup', { method: 'POST', body: JSON.stringify({ email, password, name }) })
};
